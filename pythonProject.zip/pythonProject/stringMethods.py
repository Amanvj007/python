# Python3 program to show the 
# working of upper() function 
a= 'helloWorld'
print(len(a)) 


